export const CURRENCY_OPTIONS = [
  { code: "SAR", label: "الريال السعودي (ر.س)" },
  { code: "AED", label: "الدرهم الإماراتي (د.إ)" },
  { code: "USD", label: "الدولار الأمريكي ($)" },
  { code: "JOD", label: "الدينار الأردني (د.أ)" },
  { code: "QAR", label: "الريال القطري (ر.ق)" },
  { code: "KWD", label: "الدينار الكويتي (د.ك)" },
] as const;

export type CurrencyCode = (typeof CURRENCY_OPTIONS)[number]["code"];

export function formatCurrency(amount: number, currencyCode: CurrencyCode | string) {
  return new Intl.NumberFormat("ar-SA", {
    style: "currency",
    currency: currencyCode,
    maximumFractionDigits: 0,
  }).format(amount);
}
