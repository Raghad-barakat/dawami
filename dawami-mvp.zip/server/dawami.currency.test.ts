import { describe, expect, it } from "vitest";
import { CURRENCY_OPTIONS, formatCurrency } from "../shared/currency";

describe("Dawami currency settings", () => {
  it("supports the manager currency choices", () => {
    expect(CURRENCY_OPTIONS.map(option => option.code)).toEqual(["SAR", "AED", "USD", "JOD", "QAR", "KWD"]);
  });

  it("formats payroll with the selected currency", () => {
    expect(formatCurrency(4800, "SAR")).toContain("ر.س");
    expect(formatCurrency(4800, "USD")).toContain("US$");
  });
});
