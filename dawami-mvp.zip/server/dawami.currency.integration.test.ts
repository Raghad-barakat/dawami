import { afterEach, describe, expect, it } from "vitest";
import { formatCurrency } from "../shared/currency";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type CurrencyCode = "SAR" | "AED" | "USD" | "JOD" | "QAR" | "KWD";
const caller = appRouter.createCaller({ user: undefined, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] });
let originalCurrency: CurrencyCode = "SAR";

async function restoreCurrency() {
  await caller.dawami.demo.updateConfig({ name: "شركة نواة للتقنية", workLocationName: "مكتب الرياض — حي النخيل", workLatitude: 24.774265, workLongitude: 46.738586, geofenceRadiusMeters: 250, currencyCode: originalCurrency });
}

afterEach(async () => {
  await restoreCurrency();
});

describe("Dawami currency integration", () => {
  it("persists a changed currency and reflects it in payroll output", async () => {
    const before = await caller.dawami.demo.config();
    originalCurrency = before.company.currencyCode as CurrencyCode;
    await caller.dawami.demo.updateConfig({ ...before.company, currencyCode: "USD" });

    const after = await caller.dawami.demo.config();
    const payroll = await caller.dawami.demo.payroll();
    const summary = await caller.dawami.demo.summary();

    const employeeWorkspace = after;
    expect(employeeWorkspace.company.currencyCode, "employee workspace currency").toBe("USD");
    expect(employeeWorkspace.estimatedPay, "employee workspace estimated pay").toBeGreaterThan(0);
    expect(formatCurrency(employeeWorkspace.estimatedPay, employeeWorkspace.company.currencyCode), "employee workspace formatted pay currency").toContain("US$");
    expect(payroll.length).toBeGreaterThan(0);
    expect(payroll.every(row => row.pay.includes("USD"))).toBe(true);
    expect(summary).not.toBeNull();
    expect(summary?.currencyCode).toBe("USD");
    expect(summary?.payroll).toBeGreaterThanOrEqual(0);
  });
});
