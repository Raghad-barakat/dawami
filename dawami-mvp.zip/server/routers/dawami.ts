import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createAttendanceRecord,
  createCompany,
  createMembership,
  getAttendanceForCompany,
  getAttendanceRecordById,
  getCompanyById,
  getCompanyByJoinCode,
  getMembershipForUser,
  getMembershipsForCompany,
  getUserByOpenId,
  getOpenAttendanceForUser,
  updateAttendanceRecord,
  updateCompanyByJoinCode,
} from "../db";
import { calculateDistanceMeters, calculateEstimatedPay, isWithinGeofence } from "../geo";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";

const coordinatesSchema = z.object({ latitude: z.number(), longitude: z.number() });

export const dawamiRouter = router({
  demo: router({
    config: publicProcedure.query(async () => {
      const fallback = {
        company: { name: "شركة نواة للتقنية", joinCode: "NAWA-24", workLocationName: "مكتب الرياض — حي النخيل", workLatitude: 24.774265, workLongitude: 46.738586, geofenceRadiusMeters: 250, currencyCode: "SAR" as const },
        manager: { name: "سارة العتيبي", email: "manager@dawami.app", role: "manager" as const },
        employee: { name: "أحمد محمد", email: "employee@dawami.app", role: "employee" as const, payRate: 48 },
      };
      const [company, employee] = await Promise.all([getCompanyByJoinCode("NAWA-24"), getUserByOpenId("demo-employee")]);
      if (!company || !employee) return fallback;
      const [records, membership] = await Promise.all([getAttendanceForCompany(company.id), getMembershipForUser(employee.id, company.id)]);
      const history = records.filter(({ record }) => record.employeeUserId === employee.id && Boolean(record.clockOutAt)).slice(0, 6).map(({ record }) => ({ day: record.clockInAt.toLocaleDateString("ar-SA", { weekday: "long", day: "numeric", month: "long" }), date: record.clockInAt.toLocaleDateString("ar-SA", { day: "numeric", month: "long" }), in: record.clockInAt.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }), out: record.clockOutAt?.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }) ?? "—", hours: `${Math.floor(((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000)}س ${Math.round((((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000 % 1) * 60)}د`, status: record.status === "approved" ? "معتمد" : "قيد المراجعة" }));
      const employeeHours = records.filter(({ record }) => record.employeeUserId === employee.id && Boolean(record.clockOutAt)).reduce((total, { record }) => total + ((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000, 0);
      return { company: { name: company.name, joinCode: company.joinCode, workLocationName: company.workLocationName, workLatitude: company.workLatitude, workLongitude: company.workLongitude, geofenceRadiusMeters: company.geofenceRadiusMeters, currencyCode: company.currencyCode }, manager: fallback.manager, employee: { ...fallback.employee, payRate: membership?.payRate ?? fallback.employee.payRate }, history, employeeHours, attendanceDays: history.length, estimatedPay: calculateEstimatedPay(employeeHours, membership?.payRate ?? fallback.employee.payRate) };
    }),
    clockIn: publicProcedure
      .input(coordinatesSchema)
      .mutation(async ({ input }) => {
        const [company, employee] = await Promise.all([getCompanyByJoinCode("NAWA-24"), getUserByOpenId("demo-employee")]);
        if (!company || !employee) throw new TRPCError({ code: "NOT_FOUND", message: "الحساب التجريبي غير متاح" });
        const distanceMeters = calculateDistanceMeters({ latitude: company.workLatitude, longitude: company.workLongitude }, input);
        if (!isWithinGeofence(distanceMeters, company.geofenceRadiusMeters)) throw new TRPCError({ code: "FORBIDDEN", message: `أنت خارج نطاق موقع العمل (${distanceMeters}م)` });
        const open = await getOpenAttendanceForUser(employee.id, company.id);
        if (open) throw new TRPCError({ code: "CONFLICT", message: "لديك دوام مفتوح بالفعل" });
        const id = await createAttendanceRecord({ companyId: company.id, employeeUserId: employee.id, clockInAt: new Date(), clockInLatitude: input.latitude, clockInLongitude: input.longitude, distanceFromWorksiteMeters: distanceMeters, status: "pending" });
        return { id: Number(id), distanceMeters };
      }),
    updateConfig: publicProcedure
      .input(z.object({ name: z.string().min(2), workLocationName: z.string().min(2), workLatitude: z.number().min(-90).max(90), workLongitude: z.number().min(-180).max(180), geofenceRadiusMeters: z.number().int().min(50).max(5000), currencyCode: z.enum(["SAR", "AED", "USD", "JOD", "QAR", "KWD"]) }))
      .mutation(async ({ input }) => {
        await updateCompanyByJoinCode("NAWA-24", { name: input.name, workLocationName: input.workLocationName, workLatitude: input.workLatitude, workLongitude: input.workLongitude, geofenceRadiusMeters: input.geofenceRadiusMeters, currencyCode: input.currencyCode });
        return { success: true };
      }),
    invite: publicProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(async ({ input }) => ({ success: Boolean(input.email), joinCode: "NAWA-24" })),
    join: publicProcedure
      .input(z.object({ joinCode: z.string().min(4), payRate: z.number().nonnegative().default(48) }))
      .mutation(async ({ input }) => {
        const [company, employee] = await Promise.all([getCompanyByJoinCode(input.joinCode.trim().toUpperCase()), getUserByOpenId("demo-employee")]);
        if (!company || !employee) throw new TRPCError({ code: "NOT_FOUND", message: "كود الشركة غير صحيح" });
        const existing = await getMembershipForUser(employee.id, company.id);
        if (existing) return { success: true, alreadyJoined: true, companyName: company.name };
        await createMembership({ companyId: company.id, userId: employee.id, role: "employee", payRate: input.payRate });
        return { success: true, alreadyJoined: false, companyName: company.name };
      }),
    approve: publicProcedure
      .input(z.object({ recordId: z.number().int().positive(), status: z.enum(["approved", "rejected"]) }))
      .mutation(async ({ input }) => { await updateAttendanceRecord(input.recordId, { status: input.status }); return { success: true }; }),
    updateTimes: publicProcedure
      .input(z.object({ recordId: z.number().int().positive(), clockInAt: z.coerce.date(), clockOutAt: z.coerce.date().nullable() }))
      .mutation(async ({ input }) => { await updateAttendanceRecord(input.recordId, { clockInAt: input.clockInAt, clockOutAt: input.clockOutAt, status: "pending" }); return { success: true }; }),
    summary: publicProcedure.query(async () => {
      const company = await getCompanyByJoinCode("NAWA-24");
      if (!company) return null;
      const [rows, members] = await Promise.all([getAttendanceForCompany(company.id), getMembershipsForCompany(company.id)]);
      const completed = rows.filter(({ record }) => Boolean(record.clockOutAt));
      const hours = completed.reduce((total, { record }) => total + ((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000, 0);
      const payroll = members.reduce((total, { membership }) => total + completed.filter(({ record }) => record.employeeUserId === membership.userId).reduce((memberHours, { record }) => memberHours + ((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000, 0) * membership.payRate, 0);
      return { currencyCode: company.currencyCode, employeeCount: members.filter(({ membership }) => membership.role === "employee").length, presentCount: rows.filter(({ record }) => !record.clockOutAt).length, hours, payroll, approvedPercent: completed.length ? Math.round((completed.filter(({ record }) => record.status === "approved").length / completed.length) * 100) : 0 };
    }),
    feed: publicProcedure.query(async () => {
      const company = await getCompanyByJoinCode("NAWA-24");
      if (!company) return [];
      const rows = await getAttendanceForCompany(company.id);
      return rows.slice(0, 6).map(({ record, user }) => ({ id: record.id, name: user.name ?? "موظف", initials: (user.name ?? "مو").slice(0, 2), department: "الفريق", state: record.clockOutAt ? "أنهى الدوام" : "داخل الدوام", stateTone: record.clockOutAt ? "gray" : "green", clockIn: record.clockInAt.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }), duration: record.clockOutAt ? `${Math.floor((record.clockOutAt.getTime() - record.clockInAt.getTime()) / 3_600_000)}س ${Math.round((((record.clockOutAt.getTime() - record.clockInAt.getTime()) / 3_600_000) % 1) * 60)}د` : "مفتوح", avatar: "#bfe9e4" }));
    }),
    review: publicProcedure.query(async () => {
      const company = await getCompanyByJoinCode("NAWA-24");
      if (!company) return [];
      const rows = await getAttendanceForCompany(company.id);
      return rows.map(({ record, user }) => ({ id: record.id, name: user.name ?? "موظف", initials: (user.name ?? "مو").slice(0, 2), date: record.clockInAt.toLocaleDateString("ar-SA", { day: "numeric", month: "long" }), in: record.clockInAt.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }), out: record.clockOutAt?.toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" }) ?? "—", hours: record.clockOutAt ? `${Math.floor((record.clockOutAt.getTime() - record.clockInAt.getTime()) / 3_600_000)}س ${Math.round((((record.clockOutAt.getTime() - record.clockInAt.getTime()) / 3_600_000) % 1) * 60)}د` : "—", status: record.status === "approved" ? "معتمد" : record.status === "rejected" ? "مرفوض" : "قيد المراجعة" }));
    }),
    payroll: publicProcedure.query(async () => {
      const company = await getCompanyByJoinCode("NAWA-24");
      if (!company) return [];
      const [rows, members] = await Promise.all([getAttendanceForCompany(company.id), getMembershipsForCompany(company.id)]);
      return members.filter(({ membership }) => membership.role === "employee").map(({ membership, user }) => {
        const employeeRows = rows.filter(({ record }) => record.employeeUserId === membership.userId && Boolean(record.clockOutAt));
        const hours = employeeRows.reduce((total, { record }) => total + ((record.clockOutAt?.getTime() ?? record.clockInAt.getTime()) - record.clockInAt.getTime()) / 3_600_000, 0);
        return { name: user.name ?? "موظف", initials: (user.name ?? "مو").slice(0, 2), department: "الفريق", hours: `${Math.floor(hours)}س ${Math.round((hours % 1) * 60)}د`, pay: `${calculateEstimatedPay(hours, membership.payRate).toLocaleString("ar-SA")} ${company.currencyCode}`, status: employeeRows.every(({ record }) => record.status === "approved") ? "مكتمل" : "قيد المراجعة" };
      });
    }),
    clockOut: publicProcedure
      .input(coordinatesSchema)
      .mutation(async ({ input }) => {
        const [company, employee] = await Promise.all([getCompanyByJoinCode("NAWA-24"), getUserByOpenId("demo-employee")]);
        if (!company || !employee) throw new TRPCError({ code: "NOT_FOUND", message: "الحساب التجريبي غير متاح" });
        const open = await getOpenAttendanceForUser(employee.id, company.id);
        if (!open) throw new TRPCError({ code: "NOT_FOUND", message: "لا يوجد دوام مفتوح" });
        const distanceMeters = calculateDistanceMeters({ latitude: company.workLatitude, longitude: company.workLongitude }, input);
        if (!isWithinGeofence(distanceMeters, company.geofenceRadiusMeters)) throw new TRPCError({ code: "FORBIDDEN", message: `أنت خارج نطاق موقع العمل (${distanceMeters}م)` });
        await updateAttendanceRecord(open.id, { clockOutAt: new Date(), clockOutLatitude: input.latitude, clockOutLongitude: input.longitude, status: "pending" });
        return { success: true, distanceMeters };
      }),
  }),

  validateLocation: publicProcedure
    .input(z.object({ worksite: coordinatesSchema, current: coordinatesSchema, radiusMeters: z.number().int().positive() }))
    .query(({ input }) => {
      const distanceMeters = calculateDistanceMeters(input.worksite, input.current);
      return { distanceMeters, radiusMeters: input.radiusMeters, within: isWithinGeofence(distanceMeters, input.radiusMeters) };
    }),

  company: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(2),
        joinCode: z.string().min(4).max(24),
        workLocationName: z.string().min(2),
        worksite: coordinatesSchema,
        geofenceRadiusMeters: z.number().int().min(50).max(5000),
        payRate: z.number().nonnegative().default(0),
      }))
      .mutation(async ({ ctx, input }) => {
        const companyId = await createCompany({
          name: input.name,
          joinCode: input.joinCode,
          workLocationName: input.workLocationName,
          workLatitude: input.worksite.latitude,
          workLongitude: input.worksite.longitude,
          geofenceRadiusMeters: input.geofenceRadiusMeters,
          createdByUserId: ctx.user.id,
        });
        if (companyId) await createMembership({ companyId: Number(companyId), userId: ctx.user.id, role: "manager", payRate: input.payRate });
        return { companyId: Number(companyId) };
      }),
    join: protectedProcedure
      .input(z.object({ joinCode: z.string().min(4), payRate: z.number().nonnegative().default(0) }))
      .mutation(async ({ ctx, input }) => {
        const company = await getCompanyByJoinCode(input.joinCode.trim().toUpperCase());
        if (!company) throw new TRPCError({ code: "NOT_FOUND", message: "كود الشركة غير صحيح" });
        await createMembership({ companyId: company.id, userId: ctx.user.id, role: "employee", payRate: input.payRate });
        return company;
      }),
    members: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const membership = await getMembershipForUser(ctx.user.id, input.companyId);
        if (membership?.role !== "manager") throw new TRPCError({ code: "FORBIDDEN" });
        return getMembershipsForCompany(input.companyId);
      }),
  }),

  attendance: router({
    checkIn: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive(), current: coordinatesSchema }))
      .mutation(async ({ ctx, input }) => {
        const [company, membership] = await Promise.all([
          getCompanyById(input.companyId),
          getMembershipForUser(ctx.user.id, input.companyId),
        ]);
        if (!company || membership?.role !== "employee") throw new TRPCError({ code: "FORBIDDEN" });
        const distanceMeters = calculateDistanceMeters(
          { latitude: company.workLatitude, longitude: company.workLongitude },
          input.current,
        );
        if (!isWithinGeofence(distanceMeters, company.geofenceRadiusMeters)) {
          throw new TRPCError({ code: "FORBIDDEN", message: `أنت خارج نطاق موقع العمل (${distanceMeters}م)` });
        }
        if (await getOpenAttendanceForUser(ctx.user.id, input.companyId)) {
          throw new TRPCError({ code: "CONFLICT", message: "لديك دوام مفتوح بالفعل" });
        }
        const id = await createAttendanceRecord({
          companyId: input.companyId,
          employeeUserId: ctx.user.id,
          clockInAt: new Date(),
          clockInLatitude: input.current.latitude,
          clockInLongitude: input.current.longitude,
          distanceFromWorksiteMeters: distanceMeters,
          status: "pending",
        });
        return { id: Number(id), distanceMeters };
      }),
    checkOut: protectedProcedure
      .input(z.object({ recordId: z.number().int().positive(), companyId: z.number().int().positive(), current: coordinatesSchema }))
      .mutation(async ({ ctx, input }) => {
        const [company, membership, record] = await Promise.all([
          getCompanyById(input.companyId),
          getMembershipForUser(ctx.user.id, input.companyId),
          getAttendanceRecordById(input.recordId),
        ]);
        if (!company || membership?.role !== "employee" || !record || record.employeeUserId !== ctx.user.id || record.companyId !== input.companyId) throw new TRPCError({ code: "FORBIDDEN" });
        const distanceMeters = calculateDistanceMeters(
          { latitude: company.workLatitude, longitude: company.workLongitude },
          input.current,
        );
        if (!isWithinGeofence(distanceMeters, company.geofenceRadiusMeters)) throw new TRPCError({ code: "FORBIDDEN", message: `أنت خارج نطاق موقع العمل (${distanceMeters}م)` });
        await updateAttendanceRecord(input.recordId, { clockOutAt: new Date(), clockOutLatitude: input.current.latitude, clockOutLongitude: input.current.longitude, distanceFromWorksiteMeters: Math.max(record.distanceFromWorksiteMeters, distanceMeters) });
        return { success: true, distanceMeters };
      }),
    updateTimes: protectedProcedure
      .input(z.object({ recordId: z.number().int().positive(), companyId: z.number().int().positive(), clockInAt: z.coerce.date(), clockOutAt: z.coerce.date().nullable() }))
      .mutation(async ({ ctx, input }) => {
        const membership = await getMembershipForUser(ctx.user.id, input.companyId);
        if (membership?.role !== "manager") throw new TRPCError({ code: "FORBIDDEN" });
        await updateAttendanceRecord(input.recordId, { clockInAt: input.clockInAt, clockOutAt: input.clockOutAt, status: "pending" });
        return { success: true };
      }),
    approve: protectedProcedure
      .input(z.object({ recordId: z.number().int().positive(), companyId: z.number().int().positive(), status: z.enum(["approved", "rejected"]) }))
      .mutation(async ({ ctx, input }) => {
        const membership = await getMembershipForUser(ctx.user.id, input.companyId);
        if (membership?.role !== "manager") throw new TRPCError({ code: "FORBIDDEN" });
        await updateAttendanceRecord(input.recordId, { status: input.status });
        return { success: true };
      }),
    companyFeed: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const membership = await getMembershipForUser(ctx.user.id, input.companyId);
        if (membership?.role !== "manager") throw new TRPCError({ code: "FORBIDDEN" });
        return getAttendanceForCompany(input.companyId);
      }),
    payroll: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const membership = await getMembershipForUser(ctx.user.id, input.companyId);
        if (membership?.role !== "manager") throw new TRPCError({ code: "FORBIDDEN" });
        const [rows, members] = await Promise.all([getAttendanceForCompany(input.companyId), getMembershipsForCompany(input.companyId)]);
        return members.map(({ membership: member, user }) => {
          const employeeRows = rows.filter(({ record }) => record.employeeUserId === member.userId);
          const hours = employeeRows.reduce((total, { record }) => {
            if (!record.clockOutAt) return total;
            return total + (record.clockOutAt.getTime() - record.clockInAt.getTime()) / 3_600_000;
          }, 0);
          return { user, membership: member, hours, estimatedPay: calculateEstimatedPay(hours, member.payRate) };
        });
      }),
  }),
});
