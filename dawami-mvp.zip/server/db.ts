import { and, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  AttendanceRecord,
  attendanceRecords,
  Company,
  companies,
  InsertAttendanceRecord,
  InsertCompany,
  InsertUser,
  Membership,
  memberships,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function createCompany(input: InsertCompany) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(companies).values(input);
  return result[0]?.insertId;
}

export async function getCompanyById(companyId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(companies).where(eq(companies.id, companyId)).limit(1);
  return result[0];
}

export async function getCompanyByJoinCode(joinCode: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(companies).where(eq(companies.joinCode, joinCode)).limit(1);
  return result[0];
}

export async function updateCompanyByJoinCode(joinCode: string, data: Partial<Company>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(companies).set(data).where(eq(companies.joinCode, joinCode));
}

export async function getMembershipForUser(userId: number, companyId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(memberships)
    .where(and(eq(memberships.userId, userId), eq(memberships.companyId, companyId)))
    .limit(1);
  return result[0];
}

export async function getMembershipsForCompany(companyId: number) {
  const db = await getDb();
  if (!db) return [] as Array<{ membership: Membership; user: typeof users.$inferSelect }>;
  return db
    .select({ membership: memberships, user: users })
    .from(memberships)
    .innerJoin(users, eq(users.id, memberships.userId))
    .where(eq(memberships.companyId, companyId));
}

export async function createMembership(input: typeof memberships.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(memberships).values(input);
  return result[0]?.insertId;
}

export async function createAttendanceRecord(input: InsertAttendanceRecord) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(attendanceRecords).values(input);
  return result[0]?.insertId;
}

export async function getOpenAttendanceForUser(userId: number, companyId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(attendanceRecords)
    .where(
      and(
        eq(attendanceRecords.employeeUserId, userId),
        eq(attendanceRecords.companyId, companyId),
      ),
    )
    .orderBy(desc(attendanceRecords.clockInAt))
    .limit(1);
  return result[0]?.clockOutAt ? undefined : result[0];
}

export async function getAttendanceForCompany(companyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ record: attendanceRecords, user: users })
    .from(attendanceRecords)
    .innerJoin(users, eq(users.id, attendanceRecords.employeeUserId))
    .where(eq(attendanceRecords.companyId, companyId))
    .orderBy(desc(attendanceRecords.clockInAt));
}

export async function getAttendanceRecordById(recordId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(attendanceRecords).where(eq(attendanceRecords.id, recordId)).limit(1);
  return result[0];
}

export async function updateAttendanceRecord(recordId: number, data: Partial<AttendanceRecord>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(attendanceRecords).set(data).where(eq(attendanceRecords.id, recordId));
}

export { attendanceRecords, companies, memberships, users };
