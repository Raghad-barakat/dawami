import { describe, expect, it } from "vitest";
import {
  calculateDistanceMeters,
  calculateEstimatedPay,
  calculateWorkedHours,
  formatHoursDecimal,
  isWithinGeofence,
} from "./geo";

describe("Dawami location and payroll rules", () => {
  const worksite = { latitude: 24.774265, longitude: 46.738586 };

  it("allows a location inside the configured radius", () => {
    const distance = calculateDistanceMeters(worksite, { latitude: 24.7747, longitude: 46.7383 });
    expect(distance).toBeLessThan(250);
    expect(isWithinGeofence(distance, 250)).toBe(true);
  });

  it("blocks a location outside the configured radius", () => {
    const distance = calculateDistanceMeters(worksite, { latitude: 24.78, longitude: 46.75 });
    expect(distance).toBeGreaterThan(250);
    expect(isWithinGeofence(distance, 250)).toBe(false);
  });

  it("calculates worked hours and estimated pay from an hourly rate", () => {
    const start = new Date("2024-08-20T08:00:00Z");
    const end = new Date("2024-08-20T16:30:00Z");
    expect(calculateWorkedHours(start, end)).toBe(8.5);
    expect(calculateEstimatedPay(8.5, 48)).toBe(408);
    expect(formatHoursDecimal(8.5)).toBe("8س 30د");
  });
});
