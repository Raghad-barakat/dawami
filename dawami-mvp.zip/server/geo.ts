export type Coordinates = {
  latitude: number;
  longitude: number;
};

const EARTH_RADIUS_METERS = 6_371_000;

export function calculateDistanceMeters(from: Coordinates, to: Coordinates) {
  const toRadians = (value: number) => (value * Math.PI) / 180;
  const latitudeDelta = toRadians(to.latitude - from.latitude);
  const longitudeDelta = toRadians(to.longitude - from.longitude);
  const fromLatitude = toRadians(from.latitude);
  const toLatitude = toRadians(to.latitude);

  const haversine =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(fromLatitude) * Math.cos(toLatitude) * Math.sin(longitudeDelta / 2) ** 2;

  return Math.round(2 * EARTH_RADIUS_METERS * Math.asin(Math.sqrt(haversine)));
}

export function isWithinGeofence(distanceMeters: number, radiusMeters: number) {
  return distanceMeters <= radiusMeters;
}

export function calculateWorkedHours(clockInAt: Date | number, clockOutAt: Date | number = Date.now()) {
  const start = new Date(clockInAt).getTime();
  const end = new Date(clockOutAt).getTime();
  return Math.max(0, (end - start) / (1000 * 60 * 60));
}

export function calculateEstimatedPay(workedHours: number, hourlyRate: number) {
  return Math.round(Math.max(0, workedHours) * Math.max(0, hourlyRate) * 100) / 100;
}

export function formatHoursDecimal(hours: number) {
  const safeHours = Math.max(0, hours);
  const wholeHours = Math.floor(safeHours);
  const minutes = Math.round((safeHours - wholeHours) * 60);
  return `${wholeHours}س ${minutes}د`;
}
